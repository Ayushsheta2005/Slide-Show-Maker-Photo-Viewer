document.addEventListener("DOMContentLoaded", function() {
    updateDate();
    displayPictures();
    addImageClickHandler();
});

function updateDate() {
    const currentDate = new Date();
    const dateString = currentDate.toDateString();
    document.getElementById("date").innerText =  dateString;
}

function displayPictures() {
    const gallery = document.getElementById("gallery");

    const pictureUrls = [
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
    ];

    pictureUrls.forEach(url => {
        const imgContainer = document.createElement("div");
        imgContainer.classList.add("img-container");

        const img = document.createElement("img");
        img.src = url;

        imgContainer.appendChild(img);
        gallery.appendChild(imgContainer);
    });
}

function addImageClickHandler() {
    const images = document.getElementsByClassName("img-container");

    // Convert the HTMLCollection to an array
    const imagesArray = Array.from(images);

    imagesArray.forEach(img => {
        img.addEventListener("click", function() {
            this.classList.toggle("cc");
        });
    });
}
function addGlowEffect() {
    const button = document.querySelector('.glow-button');
    button.classList.add('glow-on-click');

    // Remove the glow class after a short delay
    setTimeout(() => {
        button.classList.remove('glow-on-click');
    }, 500);
}