var totalUserNumberElement = document.getElementById("totalUserNumber");
var totalUserNumber = 0;
var targetTotalUserNumber = 976; // Target total number of users
var totalIncrementStep = Math.ceil(targetTotalUserNumber / ((1.5 * 1000) / 50)); // Calculate increment step
var totalIncrementInterval = setInterval(function () {
  totalUserNumber += totalIncrementStep; // Increment by step
  if (totalUserNumber >= targetTotalUserNumber) {
    totalUserNumber = targetTotalUserNumber; // Ensure reaching target
    clearInterval(totalIncrementInterval);
  }
  totalUserNumberElement.textContent = totalUserNumber;
}, 50);

// Animated number display for current number of users
var currentUserNumberElement = document.getElementById("currentUserNumber");
var currentUserNumber = 0;
var targetCurrentUserNumber = 85; // Target current number of users
var currentIncrementStep = Math.ceil(
  targetCurrentUserNumber / ((1.5 * 1000) / 50)
); // Calculate increment step
var currentIncrementInterval = setInterval(function () {
  currentUserNumber += currentIncrementStep; // Increment by step
  if (currentUserNumber >= targetCurrentUserNumber) {
    currentUserNumber = targetCurrentUserNumber; // Ensure reaching target
    clearInterval(currentIncrementInterval);
  }
  currentUserNumberElement.textContent = currentUserNumber;
}, 50);

// Photos and Slideshows Created per Day Chart
var photosSlideshowsCtx = document
  .getElementById("photosSlideshowsChart")
  .getContext("2d");
var photosSlideshowsChart = new Chart(photosSlideshowsCtx, {
  type: "bar",
  data: {
    labels: [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
      "Sunday",
    ],
    datasets: [
      {
        label: "Photos Created",
        backgroundColor: "rgba(122, 130, 220,0.6)",
        borderColor: "rgba(122, 130, 220, 1)",
        borderWidth: 1,
        data: [12, 19, 3, 5, 2, 3, 8],
      },
      {
        label: "Slideshows Created",
        backgroundColor: "rgba(115 , 131, 93, 0.6)",
        borderColor: "rgba(115, 131, 93, 1)",
        borderWidth: 1,
        data: [7, 11, 5, 8, 3, 7, 4],
      },
    ],
  },
  options: {
    scales: {
      y: {
        ticks: {
          beginAtZero: true,
          color: "rgb(22, 38, 57)",
        },
        grid: {
          color: "rgba(22, 38, 57,0.1)",
        },
      },
      x: {
        ticks: {
          color: "rgb(22, 38, 57)",
        },
        grid: {
          color: "rgba(22, 38, 57,0.3)",
        },
      },
    },
    plugins: {
      legend: {
        labels: {
          usePointStyle: true,
          color: "rgb(22, 38, 57)",
        },
      },
    },
  },
});
