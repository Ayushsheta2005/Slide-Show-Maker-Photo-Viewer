document.addEventListener("DOMContentLoaded", function() {
    
    displayPictures();
    addImageClickHandler();
});



function displayPictures() {
    const gallery = document.getElementById("gallery");

    const pictureUrls = [
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
        "https://via.placeholder.com/150",
    ];

    pictureUrls.forEach(url => {
        const imgContainer = document.createElement("div");
        imgContainer.classList.add("img-container");

        const img = document.createElement("img");
        img.src = url;

        imgContainer.appendChild(img);
        gallery.appendChild(imgContainer);
    });
}

function addImageClickHandler() {
    const images = document.getElementsByClassName("img-container");

    // Convert the HTMLCollection to an array
    const imagesArray = Array.from(images);

    imagesArray.forEach(img => {
        img.addEventListener("click", function() {
            this.classList.toggle("cc");
        });
    });
}