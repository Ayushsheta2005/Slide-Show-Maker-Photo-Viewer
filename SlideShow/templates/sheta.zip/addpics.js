var flag=0;
var flag1=0;
document.getElementById('imageInput').addEventListener('change', previewImages);
document.getElementById('dropContainer').addEventListener('dragover', allowDrop);
document.getElementById('dropContainer').addEventListener('drop', handleDrop);

function previewImages() {
    flag=0;
    flag1=1;
    var previewContainer = document.getElementById('imagePreview');
    var existingImages = document.querySelectorAll('.image-container'); // Get existing images

    var files = Array.from(document.getElementById('imageInput').files);

    files.forEach(function (file) {
        processFile(file);
    });
   updateChosenImages(); // Update the count with the combined images
}

function allowDrop(event) {
    // flag=1;
    event.preventDefault();
    flag=0;
    flag1=0;
}

function handleDrop(event) {
    // flag=1;
    event.preventDefault();
    var files = event.dataTransfer.files;

    Array.from(files).forEach(function (file) {
        processFile(file);
    }
    );
}

function processFile(file) {
    var reader = new FileReader();

    reader.onload = function (e) {
        if(flag1==1)
        {
            var imageContainer = document.createElement('div');
            imageContainer.classList.add('image-container'); // Add a class for styling
            
            var image = document.createElement('img');
            image.src = e.target.result;
            
            var closeButton = document.createElement('span');
            closeButton.innerHTML = '&times;'; // Use '×' for the cross icon
            closeButton.classList.add('close-icon'); // Add a class for styling
            
            closeButton.addEventListener('click', function () {
                imageContainer.remove();
                updateChosenImages(); // Update the count when an image is removed
            });
            
            imageContainer.appendChild(image);
            imageContainer.appendChild(closeButton);
            
            document.getElementById('imagePreview').appendChild(imageContainer);
            updateChosenImages();
        } // Update the count when a new image is added
        else if(flag%2==0)
        {
            var imageContainer = document.createElement('div');
            imageContainer.classList.add('image-container'); // Add a class for styling
            
            var image = document.createElement('img');
            image.src = e.target.result;
            
            var closeButton = document.createElement('span');
            closeButton.innerHTML = '&times;'; // Use '×' for the cross icon
            closeButton.classList.add('close-icon'); // Add a class for styling
            
            closeButton.addEventListener('click', function () {
                imageContainer.remove();
                updateChosenImages(); // Update the count when an image is removed
            });
            
            imageContainer.appendChild(image);
            imageContainer.appendChild(closeButton);
            
            document.getElementById('imagePreview').appendChild(imageContainer);
            updateChosenImages();
        }
        flag++;
    };
    
    reader.readAsDataURL(file);
}

function updateChosenImages() {
    var chosenImagesCount = document.querySelectorAll('.image-container').length;
    var countLabel = document.getElementById('chosenImagesCount');
    countLabel.textContent = 'Chosen Images: ' + chosenImagesCount;
}


function uploadImages() {
    var formData = new FormData(document.getElementById('imageForm'));

    // You can add logic to send the formData to the backend in the next milestones.
    console.log(formData.getAll('file')); // This will log the selected files.
    // Add logic to send the formData to the backend in the next milestones.
}

function clearAllImages() {
    var previewContainer = document.getElementById('imagePreview');
    previewContainer.innerHTML = '';
    updateChosenImages(); // Update the count after clearing all images
}