
var button = document.getElementById("click");

button.onclick = () => {
    window.alert("Please login into your account.");
}



